# Feed Reader Testing

This is a Udacity FEND project. 

This project is a web-based application that reads RSS feeds and has included tests using Jasmine (http://jasmine.github.io/).

## How to run this project

Open the index.html in your browser. It takes a moment to load and then displays the test results at the bottom.

## Dependencies
 
- Google fonts
- JQuery
- Handlebars
- JSAPI
- Jasmine

